<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    <p>Your account verification otp:</p>
    <h1>{{ $details['otp'] }}</h1>
   
  
</body>
</html>