<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    <p>Your account verification otp:</p>
    <h1><?php echo e($details['otp']); ?></h1>
   
  
</body>
</html><?php /**PATH F:\Web Development\PHP-Laravel\Projects\e_voting\resources\views/backend/user/email/sendingotp.blade.php ENDPATH**/ ?>