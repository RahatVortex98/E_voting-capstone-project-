<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>Online Voting</title>

  <!-- loader-->
  <link href="<?php echo e(asset('backendAssets/assets/css/pace.min.css')); ?>" rel="stylesheet"/>
  <script src="<?php echo e(asset('backendAssets/assets/js/pace.min.js')); ?>"></script>
  <!--favicon-->
  <link rel="icon" href="<?php echo e(asset('custom_img/f-white.png')); ?>" type="image/x-icon">
  <!-- Bootstrap core CSS-->
  <link href="<?php echo e(asset('backendAssets/assets/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="<?php echo e(asset('backendAssets/assets/css/animate.css')); ?>" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="<?php echo e(asset('backendAssets/assets/css/icons.css')); ?>" rel="stylesheet" type="text/css"/>
  <!-- Custom Style-->
  <link href="<?php echo e(asset('backendAssets/assets/css/app-style.css')); ?>" rel="stylesheet"/>
  
</head>

<body class="bg-theme bg-theme1">


<!-- Start wrapper-->
 <div id="wrapper">

 <div class="loader-wrapper"><div class="lds-ring"><div></div><div></div><div></div><div></div></div></div>
	<div class="card card-authentication1 mx-auto my-5">
		<div class="card-body">
		 <div class="card-content p-2">
		 	<div class="text-center">
		 		<img src="<?php echo e(asset('backendAssets/assets/images/logo-icon.png')); ?>" alt="logo icon">
		 	</div>
		  <div class="card-title text-uppercase text-center py-3">User Verification</div>
      <?php if(\Session::has('success')): ?>
          <div class="alert alert-success alert-dismissible fade show p-2" role="alert">
              <strong> <?php echo \Session::get('success'); ?></strong> 
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
              </button>
          </div>
      <?php endif; ?>
          
		    <form action="<?php echo e(route('sendOTP')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="hidden" name="user_id" id="user_id" value="<?php echo e($user->id); ?>">
                    <label for="exampleInputEmail" class="sr-only">Give your Email to verify</label>
                    <div class="position-relative has-icon-right">
                        <input type="email" id="exampleInputEmail" class="form-control input-shadow" autocomplete="off" name="email" placeholder="Enter Email">
                        <div class="form-control-position">
                            <i class="icon-envelope"></i>
                        </div>
                    </div>
                </div>
               
               
                <?php if(\Session::has('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo \Session::get('error'); ?>

                    </div>
                <?php endif; ?>
                <button type="submit" class="btn btn-light btn-block">Send Email</button>
                
             
			 </form>
		   </div>
		  </div>
		  
	     </div>
    
    

	</div><!--wrapper-->
	
  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo e(asset('backendAssets/assets/js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backendAssets/assets/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backendAssets/assets/js/bootstrap.min.js')); ?>"></script>
	
  <!-- sidebar-menu js -->
  <script src="<?php echo e(asset('backendAssets/assets/js/sidebar-menu.js')); ?>"></script>
  
  <!-- Custom scripts -->
  <script src="<?php echo e(asset('backendAssets/assets/js/app-script.js')); ?>"></script>
  
</body>
</html>
<?php /**PATH F:\Web Development\PHP-Laravel\Projects\e_voting\resources\views/backend/user/varify/validation.blade.php ENDPATH**/ ?>