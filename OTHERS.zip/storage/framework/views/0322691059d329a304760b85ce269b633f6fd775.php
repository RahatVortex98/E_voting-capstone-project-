

<?php $__env->startSection('page_content'); ?>
    <div class="container">
        

        <div class="row">

            <div class="col-md-12">
                <h3>Candidate Profile: <?php echo e($candidate->name); ?></h3>
            </div>
                <div class="col-md-4">
                    <div class="card profile-card-2">
                        <div class="card-img-block-2">
                            <img class="img-fluid" src="<?php echo e(asset('images/candidate/'.$candidate->created_at->format('Y/M/').'/'.$candidate->image)); ?>" alt="Candidate Image">
                        </div>
                        <div class="card-body pt-2">
                           <div class="row">
                                <div class="col-md-6">
                                    <h5 class="card-title mt-2"><?php echo e($candidate->get_organizer($candidate->organizer_id)->name); ?></h5>
                                </div>
                               
                           </div>
                        </div>
            
                        <div class="card-body border-top border-light">
                            <div class="media align-items-center">
                                <div class="media-body text-left ml-3">
                                <p> Name: <?php echo e($candidate->name); ?>     </p>               
                                </div>
                            </div>
                            <hr>
                            <div class="media align-items-center">
                                <div class="media-body text-left ml-3">
                                <p> Designation: <?php echo e($candidate->designation); ?>     </p>               
                                </div>
                            </div>
                            <hr>
                            <div class="media align-items-center">
                                <div class="media-body text-left ml-3">
                                <p> Email: <?php echo e($candidate->email); ?>     </p>               
                                </div>
                            </div>
                            <hr>
                            <div class="media align-items-center">
                                <div class="media-body text-left ml-3">
                                <p> Phone: <?php echo e($candidate->phone); ?>     </p>               
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-8">
                    <form action="<?php echo e(route('CandidateUpdate')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <input class="form-control" type="hidden" name="candidate_id" value="<?php echo e($candidate->id); ?>">
                        <div class="row mt-3" id="CandidateForm">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Candidate Name</label>
                                    <input type="text" class="form-control form-control-rounded" value="<?php echo e($candidate->name); ?>" name="candidate_name" required>
                                </div>
                            </div>
        
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="text" class="form-control form-control-rounded" value="<?php echo e($candidate->email); ?>" name="candidate_email" required>
                                </div>
                            </div>
        
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Phone</label>
                                    <input type="text" class="form-control form-control-rounded" value="<?php echo e($candidate->phone); ?>" name="candidate_phone" required>
                                </div>
                            </div>
        
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Designation</label>
                                    <input type="text" class="form-control form-control-rounded" value="<?php echo e($candidate->designation); ?>" name="designation" required>
                                </div>
                            </div>
        
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Image: <span style="color: lime;font-weight:bold;">(Upload to Change)</span></label>
                                    <input type="file" class="form-control form-control-rounded"  name="img">
                                </div>
                            </div>
        
                        </div>
                        
                        <div class="form-group">
                          <button type="submit" class="btn btn-success btn-round px-5">Save Changes</button>
                          <a href="<?php echo e(route('portalChange', $candidate->voting_portal_id)); ?>"  class="btn btn-dark btn-round px-5">Back</a>
                        </div>
                    </form>
                </div>
           
        </div>

       
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_js'); ?>
<link href="https://cdn.jsdelivr.net/npm/tom-select@2.0.0-rc.4/dist/css/tom-select.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/tom-select@2.0.0-rc.4/dist/js/tom-select.complete.min.js"></script>
<script>
    new TomSelect("#OrganizerList",{
        create: false,
        sortField: {
            field: "text",
            direction: "asc"
        }
    });
</script>

<script>
    function ADDFORM(){

        console.log('hekko');
        var form = document.getElementById('items');
       
        form.innerHTML+= 
        '<hr>'+
        '<div class="row">'+
           
            '<div class="col-md-6">'+
                '<div class="form-group">'+
                    '<label>Name</label>'+
                    '<input type="text" class="form-control form-control-rounded" name="candidate_name[]" required>'+
                '</div>'+
            '</div>'+
            '<div class="col-md-6">'+
                '<div class="form-group">'+
                    '<label>Email</label>'+
                    '<input type="text" class="form-control form-control-rounded" name="candidate_email[]" required>'+
                '</div>'+
            '</div>'+
            '<div class="col-md-4">'+
                '<div class="form-group">'+
                    '<label>Phone</label>'+
                    '<input type="text" class="form-control form-control-rounded" name="candidate_phone[]" required>'+
                '</div>'+
            '</div>'+
            '<div class="col-md-4">'+
                '<div class="form-group">'+
                    '<label>Designation</label>'+
                    '<input type="text" class="form-control form-control-rounded" name="designation[]" required>'+
                '</div>'+
            '</div>'+
            '<div class="col-md-4">'+
                '<div class="form-group">'+
                    '<label>Image</label>'+
                    '<input type="file" class="form-control form-control-rounded" name="img[]" required>'+
                '</div>'+
            '</div>'+
        '</div>'+
       '<br>';
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\PHP-Laravel\Projects\e_voting\resources\views/backend/candidate/change.blade.php ENDPATH**/ ?>