

<?php $__env->startSection('page_content'); ?>
    
<section>
    <div class="">
        <div class="row">
            <?php if($polls->isNotEmpty()): ?>
            <?php $__currentLoopData = $polls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4">
                    <div class="card profile-card-2">
                       
                        <div class="card-body pt-2">
                            <h5 class="card-title text-center"><?php echo e($data->position); ?></h5>
                        </div>

                        <div class="card-body border-top border-light">
                            <div class="media align-items-center">
                                <div class="media-body text-center ml-3">
                                  <p> Date: <?php echo e($data->date); ?>     </p>
                                </div>
                            </div>
                            <hr>
                            <div class="media align-items-center">
                                <div class="media-body text-center ml-3">
                                  <p> Start: <?php echo e($data->start_time); ?>     </p>
                                </div>
                            </div>
                            <hr>
                            <div class="media align-items-center">
                                <div class="media-body text-center ml-3">
                                  <p> End: <?php echo e($data->end_time); ?>     </p>
                                </div>
                            </div>
                            <hr>
                            <div class="media align-items-center">
                                <div class="media-body text-center ml-3">
                                 <a href="<?php echo e(route('GetToVote', $data->id)); ?>">
                                    <button class="btn btn-round btn-success">View</button>
                                 </a>
                                </div>
                            </div>
                            
                           
                        </div>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>
            No Available Polls

         <?php endif; ?>
        </div>
    </div>
</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.userlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\PHP-Laravel\Projects\e_voting\resources\views/backend/user/home/index.blade.php ENDPATH**/ ?>