

<?php $__env->startSection('page_content'); ?>
    
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\PHP-Laravel\Projects\e_voting\resources\views/backend/admin/home/home.blade.php ENDPATH**/ ?>