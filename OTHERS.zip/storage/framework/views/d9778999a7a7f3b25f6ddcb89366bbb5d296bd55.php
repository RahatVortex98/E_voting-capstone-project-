

<?php $__env->startSection('page_content'); ?>
    <div class="container">
      <div class="row mt-3">


        <div class="col-md-12">

            <h4 class="mt-2 mb-3">User List</h4>
              <div class="table-responsive">
                <table class="table" id="userTable" style="color:black;background-color:aquamarine;">
                  <thead>
                    <tr>
                      <th scope="col">SL</th>
                      <th scope="col">Name</th>
                      <th scope="col">Email</th>
                      <th scope="col">Phone</th>

                    </tr>
                  </thead>
                  <tbody>

                    <?php if($users->isNotEmpty()): ?>

                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <th scope="row"><?php echo e($key+1); ?></th>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e($data->email); ?></td>
                            <td><?php echo e($data->phone); ?></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>


                  </tbody>
                </table>
            </div>
        </div>

      </div><!--End Row-->

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer_js'); ?>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css"/>
<script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.3.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
<script>
    $(document).ready( function () {
        $('#userTable').DataTable();
    } );

    console.log('asasd');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\PHP-Laravel\Projects\e_voting\resources\views/backend/organizer/user-list/list.blade.php ENDPATH**/ ?>